line 1 - missing name
line 2 - name with no space
line 3 - name with letter after space
line 4 - name with too many letters
line 5 - name with no letters
line 6 - name with too few numbers
line 7 - name with too many numbers
line 8 - missing title
line 9 - missing section
line 10 - section with no digits
line 11 - missing credits
line 12 - too few credits
line 13 - too many credits
line 14 - missing instructor
line 15 - missing meeting days
line 16 - missing start time or end time
line 17 - section with missing digit
line 18 - empty instructor
line 19 - invalid meeting days
line 20 - meeting times on arranged section (extra tokens)
line 21 - invalid start time
line 22 - end time before start time
line 23 - empty meeting days
line 24 - two of the same day (T) in the meeting days string
line 25 - extra token